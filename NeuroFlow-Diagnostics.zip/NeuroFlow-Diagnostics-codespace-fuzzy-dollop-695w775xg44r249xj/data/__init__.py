"""Data subpackage."""

from . import preprocessing

__all__ = ['preprocessing']
